package com.inatel.stockquotemanager.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity(name="stock_quote")
public class StockQuote {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO,generator="native")
	@GenericGenerator(name = "native",strategy = "native")
	@Column(name="id") 
	private Integer id;
	private Date date;
    private float quote;
	@ManyToOne
	@JoinColumn(name="stock_id")  
	private Stock stock;
	 
	public StockQuote(int id, Date date, float quote, Stock stock) {
		super();
		this.id = id;
		this.date = date;
		this.quote = quote;
		this.stock = stock;
	}


	public StockQuote() {
		
	}


/*	public int getId() {
		return id;
	}*/


	public void setId(int id) {
		this.id = id;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public float getQuote() {
		return quote;
	}


	public void setQuote(float quote) {
		this.quote = quote;
	}


	public void setStock(Stock stock) {
		this.stock = stock;
	}
	
	
	public String getStockId() {
		
		return stock.getId();
	}

	
}
