package com.inatel.stockquotemanager.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inatel.stockquotemanager.models.StockQuote;
import com.inatel.stockquotemanager.repositories.StockQuoteRepository;
 
 
@Service
public class StockQuoteService {

	@Autowired
	private StockQuoteRepository repo;
	
	public List<StockQuote> listAll(){
		return repo.findAll();
	}
	
	public void save(StockQuote stockQuote) {
		repo.save(stockQuote);
	}
	
	public StockQuote get(Integer id) {
		return repo.findById(id).get();
	}
	
	public void delete(Integer id) {
		repo.deleteById(id);
	}
}
