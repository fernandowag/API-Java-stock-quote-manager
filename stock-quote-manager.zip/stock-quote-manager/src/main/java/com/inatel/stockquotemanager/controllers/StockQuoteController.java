package com.inatel.stockquotemanager.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inatel.stockquotemanager.models.Stock;
import com.inatel.stockquotemanager.models.StockQuote;
import com.inatel.stockquotemanager.services.StockQuoteService;
import com.inatel.stockquotemanager.services.StockService;

@RestController
public class StockQuoteController {

	@Autowired 
	private StockQuoteService stockQuoteService;
	@Autowired
	private StockService stockService;
	
	@RequestMapping(value = "/addStockQuote", method =  RequestMethod.POST)
    public ResponseEntity<Object> Post(@Validated @RequestBody StockQuote stockQuote )
    {
		
		String id = stockQuote.getStockId();	
		
		try {
			
			Optional<Stock> stock = Optional.ofNullable(stockService.get(id));
			if(stock.isPresent()) {				
				stockQuoteService.save(stockQuote);        	
				return new ResponseEntity<>("Success",HttpStatus.CREATED);
			}
		}
       catch(java.util.NoSuchElementException ex) {
        	return new ResponseEntity<>("Stock does not exists",HttpStatus.NOT_FOUND);
        }
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			 
    }
	
    @RequestMapping(value = "/deleteStockQuote/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") Integer id)
    {
    	Optional<StockQuote> stockQuote = Optional.ofNullable(stockQuoteService.get(id));
        if(stockQuote.isPresent()){
        	stockQuoteService.delete(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
	
	
}
