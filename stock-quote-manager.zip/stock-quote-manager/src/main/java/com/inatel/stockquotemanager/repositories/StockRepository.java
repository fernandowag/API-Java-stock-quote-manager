package com.inatel.stockquotemanager.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inatel.stockquotemanager.models.Stock;

public interface StockRepository extends JpaRepository<Stock, String>{

}
