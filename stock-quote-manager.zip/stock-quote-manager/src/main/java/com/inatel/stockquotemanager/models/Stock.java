package com.inatel.stockquotemanager.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
 

@Entity(name="stock")
public class Stock {
    @Id
	@Column(name="stock_id", unique = true, nullable = false)
	private String stock_id;
	@Column(name="description")
	private String description;
	@OneToMany(mappedBy = "stock", targetEntity = StockQuote.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	
	private List<StockQuote> stockQuotes;


	public Stock(String stock_id, String description) {
		super();
		this.stock_id = stock_id;
		this.description = description;
	}

	public Stock() {

	}

	public String getId() {
		return stock_id;
	}

	public void setId(String stock_id) {
		this.stock_id = stock_id;
	}
	
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	 public List<StockQuote> getStockQuotes() {
		    return stockQuotes;
		  }
		  public void setStockQuotes(List<StockQuote> stockQuotes) {
		    this.stockQuotes = stockQuotes;
		  }
	
	
}