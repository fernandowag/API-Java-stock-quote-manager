package com.inatel.stockquotemanager.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inatel.stockquotemanager.models.Stock;
import com.inatel.stockquotemanager.repositories.StockRepository;

@Service
public class StockService {
	
	@Autowired
	private StockRepository repo;
	
	public List<Stock> listAll(){
		return repo.findAll();
	}
	
	public void save(Stock stock) {
		repo.save(stock);
	}
	
	public Stock get(String id) {
		return repo.findById(id).get();
	}
	
	public void delete(String id) {
		repo.deleteById(id);
	}
}
