package com.inatel.stockquotemanager.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inatel.stockquotemanager.models.StockQuote;

public interface StockQuoteRepository extends JpaRepository<StockQuote, Integer>{

}
