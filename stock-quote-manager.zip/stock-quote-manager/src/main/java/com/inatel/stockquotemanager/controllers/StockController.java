package com.inatel.stockquotemanager.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inatel.stockquotemanager.models.Stock;
import com.inatel.stockquotemanager.services.StockService;

@RestController
public class StockController {

	@Autowired 
	private StockService service;
	
	 @RequestMapping(value = "/", method = RequestMethod.GET)
	 public String home(){
	        return "StockQuote API";
	    }
	
	
	@RequestMapping(value = "/stock", method = RequestMethod.GET)
	public List<Stock> list(){
		return service.listAll();
	}
	
	@RequestMapping(value = "/stock/{id}", method = RequestMethod.GET)
    public ResponseEntity<Stock> GetById(@PathVariable(value = "id") String id)
    {
        Optional<Stock> stock = Optional.ofNullable(service.get(id));
        if(stock.isPresent())
            return new ResponseEntity<Stock>(stock.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
	
	@RequestMapping(value = "/addStock", method =  RequestMethod.POST)
    public void Post(@Validated @RequestBody Stock stock)
    {
        service.save(stock);
    }
	
    @RequestMapping(value = "/deleteStock/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id")  String id)
    {
    	 Optional<Stock> stock = Optional.ofNullable(service.get(id));
        if(stock.isPresent()){
            service.delete(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
	
}
