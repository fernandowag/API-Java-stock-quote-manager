package com.inatel.stockquotemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockQuoteManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
